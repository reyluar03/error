-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2020 at 11:17 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `actimai-probe`
--

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE `email` (
  `id` int(11) NOT NULL,
  `SMTP Host` varchar(100) NOT NULL,
  `SMTP Port` varchar(100) NOT NULL,
  `SMTP Protocol` varchar(100) NOT NULL,
  `Email Sender` varchar(100) NOT NULL,
  `Sender Name` varchar(100) NOT NULL,
  `Sender Password` varchar(100) NOT NULL,
  `Email Receiver` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`id`, `SMTP Host`, `SMTP Port`, `SMTP Protocol`, `Email Sender`, `Sender Name`, `Sender Password`, `Email Receiver`) VALUES
(1, 'smtp.gmail.com', '587', 'tls', 'reydelcastilloluarjr@gmail.com', 'Actimai Support', 'Thalia35251501015657984', 'rey.luarjr@actimai.com');

-- --------------------------------------------------------

--
-- Table structure for table `metric`
--

CREATE TABLE `metric` (
  `id` int(11) NOT NULL,
  `company` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `processName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `metric`
--

INSERT INTO `metric` (`id`, `company`, `department`, `processName`) VALUES
(1, 'ACTIMAI', 'RPA', 'TEST-PROCESS');

-- --------------------------------------------------------

--
-- Table structure for table `metric-log`
--

CREATE TABLE `metric-log` (
  `id` int(11) NOT NULL,
  `probeNumber` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cpu` varchar(100) NOT NULL,
  `memory` varchar(100) NOT NULL,
  `storage` varchar(100) NOT NULL,
  `type` int(11) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `metric-log`
--

INSERT INTO `metric-log` (`id`, `probeNumber`, `timestamp`, `cpu`, `memory`, `storage`, `type`, `message`) VALUES
(1, 1, '2020-05-20 02:55:25', '51', '7.9', '1486', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `email`
--
ALTER TABLE `email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `metric`
--
ALTER TABLE `metric`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `metric-log`
--
ALTER TABLE `metric-log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `email`
--
ALTER TABLE `email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `metric`
--
ALTER TABLE `metric`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `metric-log`
--
ALTER TABLE `metric-log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
