<?php
$ip_server = $_SERVER['SERVER_ADDR'];
echo $ip_server;                                                                          
?>
